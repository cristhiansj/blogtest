How to create blog use mongodb and php
-------------

Demo app [here](http://phpmongodb-duythien.rhcloud.com)

Backend [here](http://phpmongodb-duythien.rhcloud.com/admin)

	username: duythien

	password: duythien
	
	
Reading tutorial here

http://www.sitepoint.com/building-simple-blog-app-mongodb-php/
